//
// Created by pc002 on 2021/6/1.
//

#ifndef PROJECTNAME_RANDOM_H
#define PROJECTNAME_RANDOM_H

namespace FLT64 {
    double boost_rand(float _min = -999.9999f, float _max = 999.9999f);
}
namespace INT8{
    long long boost_rand(long long _min=-999,long long _max=999);
}
#endif //PROJECTNAME_RANDOM_H
