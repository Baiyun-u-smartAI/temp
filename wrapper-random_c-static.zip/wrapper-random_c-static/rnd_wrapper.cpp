//
// Created by pc002 on 2021/6/1.
//

#include "rnd_wrapper.h"
#include "random.h"
extern double Rand_FLT64(double n1,double n2){
    return FLT64::boost_rand(n1,n2);
}

extern long long Rand_INT8(long long n1,long long n2){
    return INT8::boost_rand(n1,n2);
}