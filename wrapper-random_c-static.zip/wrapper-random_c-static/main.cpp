#include <iostream>
#include "random.h"
int main(){

    for (int i = 0; i < 5; ++i) {
        std::cout<<INT8::boost_rand()<<std::endl;
    }
    
    return 0;
}
