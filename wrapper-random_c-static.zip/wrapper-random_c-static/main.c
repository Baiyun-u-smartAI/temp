#include <stdio.h>
#include "rnd_wrapper.h"
int main(){

    for (int i = 0; i < 5; ++i) {
        printf("%d\n", Rand_INT8(1,5));
    }
    
    return 0;
}
