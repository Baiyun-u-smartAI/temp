//
// Created by pc002 on 2021/6/1.
//

#include "random.h"
#include <iostream>
#include <boost/random.hpp>
#include <boost/random/random_device.hpp>
double FLT64::boost_rand(float _min , float _max ) {
    boost::random::random_device rng;
    boost::mt19937 gen(rng);
    boost::uniform_real<> uni_dist(_min, _max);
    boost::variate_generator<boost::mt19937 &, boost::uniform_real<> > random(gen, uni_dist);
    return random();
}
long long INT8::boost_rand(long long _min,long long _max){
    boost::random::random_device rng;
    boost::mt19937 gen(rng);
    boost::uniform_int<long long int> uni_dist(_min, _max);
    boost::variate_generator<boost::mt19937&, boost::uniform_int<long long int> > random(gen,uni_dist);
    return random();
}