//
// Created by pc002 on 2021/6/5.
//

#ifndef PROJECTNAME_SHUFFLE_H
#define PROJECTNAME_SHUFFLE_H
#include <cstddef>
void IntArr_shuffle(int* src,size_t size);
#endif //PROJECTNAME_SHUFFLE_H
