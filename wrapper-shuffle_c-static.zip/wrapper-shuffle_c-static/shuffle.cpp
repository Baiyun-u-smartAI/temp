//
// Created by pc002 on 2021/6/5.
//

#include "shuffle.h"
#include <random>
#include <algorithm>
#include <vector>
using namespace std;

void IntArr_shuffle(int* src,size_t size){
    vector<int> toShuffle(src,src+size);
    random_device generator;
    mt19937 engine(generator());
    shuffle(toShuffle.begin(),toShuffle.end(),engine);
    copy(toShuffle.begin(),toShuffle.end(),src);
}