//
// Created by pc002 on 2021/6/5.
//

#include "shuffle_c.h"
#include "shuffle.h"
extern void shuffle_I_Arr(int* src,size_t size){
    IntArr_shuffle(src,size);
}