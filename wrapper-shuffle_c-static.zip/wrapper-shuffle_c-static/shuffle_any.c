//
// Created by pc002 on 2021/6/5.
//
#include "shuffle_c.h"
#include <stdlib.h>
#include <string.h>
void shuffle_any(void* src,size_t ElementsCounts, size_t sizeofElement){
    int* index=calloc(ElementsCounts,sizeof(int));
    for (int i = 0; i < ElementsCounts; ++i) {
        index[i]=i;
    }
    shuffle_I_Arr(index,ElementsCounts);
    void* temp=calloc(ElementsCounts,sizeofElement);
    memcpy(temp,src,sizeofElement*ElementsCounts);
    for (int i = 0; i < ElementsCounts; ++i) {
        memcpy((char*)src+sizeofElement*i, (char*)temp+sizeofElement*index[i], sizeofElement);
    }

    free(temp);
    free(index);
}